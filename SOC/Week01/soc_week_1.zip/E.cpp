// हर हर महादेव
using namespace std;
#include <bits/stdc++.h>


int main(){
	ios::sync_with_stdio(false);cin.tie(0);
	int w,h,n;
	cin >> w >> h >> n;
	set<int> pt[2];
	multiset<int> dif[2];
	pt[0].insert(0);pt[0].insert(h);
	dif[0].insert(h);
	
	pt[1].insert(0);pt[1].insert(w);
	dif[1].insert(w);
	while(n--){
		char c;
		int x;
		cin >> c >> x;
		int i = (c == 'V');
		int aft = *pt[i].lower_bound(x),bef = *prev(pt[i].lower_bound(x));
		dif[i].erase(dif[i].find(aft-bef));
		dif[i].insert(aft-x);
		dif[i].insert(x-bef);
		pt[i].insert(x);
		cout << (long long int)*prev(dif[0].end()) * *prev(dif[1].end()) << '\n';
	}
	return 0;
}
