// हर हर महादेव
using namespace std;
#include <bits/stdc++.h>

int main(){
	int n;
	cin >> n;
	vector<int> a(n);
	for(int i = 0; i < n; i++){
		cin >> a[i];
	}
	set<int> all(a.begin(),a.end());
	all.erase(all.begin());
	cout << (all.empty() ? "NO" : to_string(*all.begin()));
	return (0-0);
}
