// हर हर महादेव
using namespace std;
#include <bits/stdc++.h>

void testcase(){
	int n;
	cin >> n;
	vector<int> a(n);
	for(int i = 0; i < n; i++){
		cin >> a[i];
	}
	deque<int> all;
	for(int i = 0; i < n; i++){
		if(all.empty())
			all.push_back(a[i]);
		else{
			if(a[i] < all[0]){
				all.push_front(a[i]);
			}
			else{
				all.push_back(a[i]);
			}
		}
	}
	for(int x : all)cout << x << ' ';
	cout << '\n';
}


int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	int tt = 1;
	cin >> tt;
	while(tt--){
		testcase();
	}
	return (0-0);
}
