// हर हर महादेव
#include <bits/stdc++.h>
using namespace std;

int main(){
	int n;
	cin >> n;
	vector<int> a(n);
	for(int i = 0; i < n; i++){
		cin >> a[i];
	}
	set<int> all;
	vector<int> res;
	for(int i = n-1; i >= 0; i--){
		if(all.find(a[i]) == all.end()){
			res.push_back(a[i]);
		}
		all.insert(a[i]);
	}
	reverse(res.begin(),res.end());
	cout << res.size() << '\n';
	for(int x : res)
		cout << x << ' ';
	return 0;
}

