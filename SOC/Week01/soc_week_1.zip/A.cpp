// हर हर महादेव
#include <bits/stdc++.h>
using namespace std;

void testcase(){
	int n;
	cin >> n;
	vector<int> a(n);
	map<int,int> freq;
	for(int i = 0; i < n; i++){
		cin >> a[i];
		freq[a[i]]++;
	}
	for(int i = 0; i < n; i++){
		if(freq[a[i]] >= 3){
			cout << a[i] << '\n';
			return;
		}
	}
	cout << "-1\n";
}

int main(){
	int tt;
	cin >> tt;
	while(tt--){
		testcase();
	}
	return 0;
}

